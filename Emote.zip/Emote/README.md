# Emote
An app used for patients with BPD to help them keep track of their emotional states.
## Contributor(s)
- Brent cocu
