package com.example.brentcocu.emote.util

object Constants {
    const val DB_NAME = "EmoteDB"
    const val SP_GLOBAL_KEY = "Settings"
}